
public interface Movable {
	// returns speed in MPH 
	double getSpeed();
	
	//returns price in USDollar
		double getPrice();
}
